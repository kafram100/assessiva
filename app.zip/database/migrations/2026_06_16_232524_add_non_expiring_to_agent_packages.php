<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('agent_packages', function (Blueprint $table) {
            $table->boolean('non_expiring')->default(false)->after('voice_minutes');
        });
    }

    public function down(): void
    {
        Schema::table('agent_packages', function (Blueprint $table) {
            $table->dropColumn('non_expiring');
        });
    }
};
