<?php

namespace App\Services;

use App\Models\AgentPackage;

class ChatbotService
{
    public function respond(string $message): string
    {
        $message = strtolower(trim($message));

        $network = $this->detectNetwork($message);

        if (!$network) {
            return "Which network are you interested in?\n\n• MTN — type \"MTN prices\"\n• Telecel — type \"Telecel prices\"\n• AirtelTigo — type \"AirtelTigo prices\"";
        }

        $packages = AgentPackage::where('is_active', true)
            ->where('network_type', $network)
            ->where(function ($q) {
                $q->where('role', 'all')->orWhere('role', 'agent');
            })
            ->orderBy('sort_order')
            ->get();

        if ($packages->isEmpty()) {
            return "Sorry, no packages found for {$network}.";
        }

        $response = "{$network} Data Prices:\n\n";
        foreach ($packages as $pkg) {
            $size = $pkg->package_size_gb
                ? $pkg->package_size_gb . ' GB'
                : $pkg->package_size_mb . ' MB';
            $response .= "• {$size} — GH₵ " . number_format($pkg->price, 2) . "\n";
        }

        $response .= "\nReply \"buy\" to place an order or ask for another network.";

        return $response;
    }

    private function detectNetwork(string $message): ?string
    {
        if (str_contains($message, 'mtn')) return 'MTN';
        if (str_contains($message, 'telecel') || str_contains($message, 'vodafone')) return 'VODAFONE';
        if (str_contains($message, 'airtel') || str_contains($message, 'tigo')) return 'AIRTELTIGO';

        return null;
    }
}
