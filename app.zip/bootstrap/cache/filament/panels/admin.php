<?php return array (
  'livewireComponents' => 
  array (
    'app.filament.resources.agent-package-resource.pages.create-agent-package' => 'App\\Filament\\Resources\\AgentPackageResource\\Pages\\CreateAgentPackage',
    'app.filament.resources.agent-package-resource.pages.edit-agent-package' => 'App\\Filament\\Resources\\AgentPackageResource\\Pages\\EditAgentPackage',
    'app.filament.resources.agent-package-resource.pages.list-agent-packages' => 'App\\Filament\\Resources\\AgentPackageResource\\Pages\\ListAgentPackages',
    'app.filament.resources.agent-store-setting-resource.pages.create-agent-store-setting' => 'App\\Filament\\Resources\\AgentStoreSettingResource\\Pages\\CreateAgentStoreSetting',
    'app.filament.resources.agent-store-setting-resource.pages.edit-agent-store-setting' => 'App\\Filament\\Resources\\AgentStoreSettingResource\\Pages\\EditAgentStoreSetting',
    'app.filament.resources.agent-store-setting-resource.pages.list-agent-store-settings' => 'App\\Filament\\Resources\\AgentStoreSettingResource\\Pages\\ListAgentStoreSettings',
    'app.filament.resources.api-config-resource.pages.create-api-config' => 'App\\Filament\\Resources\\ApiConfigResource\\Pages\\CreateApiConfig',
    'app.filament.resources.api-config-resource.pages.edit-api-config' => 'App\\Filament\\Resources\\ApiConfigResource\\Pages\\EditApiConfig',
    'app.filament.resources.api-config-resource.pages.list-api-configs' => 'App\\Filament\\Resources\\ApiConfigResource\\Pages\\ListApiConfigs',
    'app.filament.resources.api-log-resource.pages.list-api-logs' => 'App\\Filament\\Resources\\ApiLogResource\\Pages\\ListApiLogs',
    'app.filament.resources.api-log-resource.pages.view-api-log' => 'App\\Filament\\Resources\\ApiLogResource\\Pages\\ViewApiLog',
    'app.filament.resources.balance-history-resource.pages.create-balance-history' => 'App\\Filament\\Resources\\BalanceHistoryResource\\Pages\\CreateBalanceHistory',
    'app.filament.resources.balance-history-resource.pages.edit-balance-history' => 'App\\Filament\\Resources\\BalanceHistoryResource\\Pages\\EditBalanceHistory',
    'app.filament.resources.balance-history-resource.pages.list-balance-histories' => 'App\\Filament\\Resources\\BalanceHistoryResource\\Pages\\ListBalanceHistories',
    'app.filament.resources.customer-package-resource.pages.create-customer-package' => 'App\\Filament\\Resources\\CustomerPackageResource\\Pages\\CreateCustomerPackage',
    'app.filament.resources.customer-package-resource.pages.edit-customer-package' => 'App\\Filament\\Resources\\CustomerPackageResource\\Pages\\EditCustomerPackage',
    'app.filament.resources.customer-package-resource.pages.list-customer-packages' => 'App\\Filament\\Resources\\CustomerPackageResource\\Pages\\ListCustomerPackages',
    'app.filament.resources.dealer-package-resource.pages.create-dealer-package' => 'App\\Filament\\Resources\\DealerPackageResource\\Pages\\CreateDealerPackage',
    'app.filament.resources.dealer-package-resource.pages.edit-dealer-package' => 'App\\Filament\\Resources\\DealerPackageResource\\Pages\\EditDealerPackage',
    'app.filament.resources.dealer-package-resource.pages.list-dealer-packages' => 'App\\Filament\\Resources\\DealerPackageResource\\Pages\\ListDealerPackages',
    'app.filament.resources.dealer-resource.pages.create-dealer' => 'App\\Filament\\Resources\\DealerResource\\Pages\\CreateDealer',
    'app.filament.resources.dealer-resource.pages.edit-dealer' => 'App\\Filament\\Resources\\DealerResource\\Pages\\EditDealer',
    'app.filament.resources.dealer-resource.pages.list-dealers' => 'App\\Filament\\Resources\\DealerResource\\Pages\\ListDealers',
    'app.filament.resources.mtn-mashup-resource.pages.list-mtn-mashups' => 'App\\Filament\\Resources\\MtnMashupResource\\Pages\\ListMtnMashups',
    'app.filament.resources.notification-resource.pages.create-notification' => 'App\\Filament\\Resources\\NotificationResource\\Pages\\CreateNotification',
    'app.filament.resources.notification-resource.pages.edit-notification' => 'App\\Filament\\Resources\\NotificationResource\\Pages\\EditNotification',
    'app.filament.resources.notification-resource.pages.list-notifications' => 'App\\Filament\\Resources\\NotificationResource\\Pages\\ListNotifications',
    'app.filament.resources.notification-resource.pages.view-notification' => 'App\\Filament\\Resources\\NotificationResource\\Pages\\ViewNotification',
    'app.filament.resources.order-resource.pages.create-order' => 'App\\Filament\\Resources\\OrderResource\\Pages\\CreateOrder',
    'app.filament.resources.order-resource.pages.edit-order' => 'App\\Filament\\Resources\\OrderResource\\Pages\\EditOrder',
    'app.filament.resources.order-resource.pages.list-orders' => 'App\\Filament\\Resources\\OrderResource\\Pages\\ListOrders',
    'app.filament.resources.order-status-history-resource.pages.list-order-status-histories' => 'App\\Filament\\Resources\\OrderStatusHistoryResource\\Pages\\ListOrderStatusHistories',
    'app.filament.resources.order-status-history-resource.pages.view-order-status-history' => 'App\\Filament\\Resources\\OrderStatusHistoryResource\\Pages\\ViewOrderStatusHistory',
    'app.filament.resources.payment-config-resource.pages.create-payment-config' => 'App\\Filament\\Resources\\PaymentConfigResource\\Pages\\CreatePaymentConfig',
    'app.filament.resources.payment-config-resource.pages.edit-payment-config' => 'App\\Filament\\Resources\\PaymentConfigResource\\Pages\\EditPaymentConfig',
    'app.filament.resources.payment-config-resource.pages.list-payment-configs' => 'App\\Filament\\Resources\\PaymentConfigResource\\Pages\\ListPaymentConfigs',
    'app.filament.resources.support-ticket-resource.pages.edit-support-ticket' => 'App\\Filament\\Resources\\SupportTicketResource\\Pages\\EditSupportTicket',
    'app.filament.resources.support-ticket-resource.pages.list-support-tickets' => 'App\\Filament\\Resources\\SupportTicketResource\\Pages\\ListSupportTickets',
    'app.filament.resources.user-resource.pages.create-user' => 'App\\Filament\\Resources\\UserResource\\Pages\\CreateUser',
    'app.filament.resources.user-resource.pages.edit-user' => 'App\\Filament\\Resources\\UserResource\\Pages\\EditUser',
    'app.filament.resources.user-resource.pages.list-users' => 'App\\Filament\\Resources\\UserResource\\Pages\\ListUsers',
    'app.filament.resources.wallet-topup-resource.pages.create-wallet-topup' => 'App\\Filament\\Resources\\WalletTopupResource\\Pages\\CreateWalletTopup',
    'app.filament.resources.wallet-topup-resource.pages.edit-wallet-topup' => 'App\\Filament\\Resources\\WalletTopupResource\\Pages\\EditWalletTopup',
    'app.filament.resources.wallet-topup-resource.pages.list-wallet-topups' => 'App\\Filament\\Resources\\WalletTopupResource\\Pages\\ListWalletTopups',
    'app.filament.pages.agent-monthly-orders' => 'App\\Filament\\Pages\\AgentMonthlyOrders',
    'app.filament.pages.auth.forgot-password' => 'App\\Filament\\Pages\\Auth\\ForgotPassword',
    'app.filament.pages.auth.login' => 'App\\Filament\\Pages\\Auth\\Login',
    'app.filament.pages.daily-balance' => 'App\\Filament\\Pages\\DailyBalance',
    'app.filament.pages.dashboard' => 'App\\Filament\\Pages\\Dashboard',
    'app.filament.pages.data-provider-settings' => 'App\\Filament\\Pages\\DataProviderSettings',
    'app.filament.pages.payment-settings' => 'App\\Filament\\Pages\\PaymentSettings',
    'app.filament.pages.profit-report' => 'App\\Filament\\Pages\\ProfitReport',
    'app.filament.pages.sales-analytics' => 'App\\Filament\\Pages\\SalesAnalytics',
    'app.filament.pages.smtp-settings' => 'App\\Filament\\Pages\\SmtpSettings',
    'app.filament.widgets.wallet-topup-stats' => 'App\\Filament\\Widgets\\WalletTopupStats',
    'filament.livewire.database-notifications' => 'Filament\\Livewire\\DatabaseNotifications',
    'filament.pages.auth.edit-profile' => 'Filament\\Pages\\Auth\\EditProfile',
    'filament.livewire.global-search' => 'Filament\\Livewire\\GlobalSearch',
    'filament.livewire.notifications' => 'Filament\\Livewire\\Notifications',
    'filament.pages.auth.password-reset.reset-password' => 'Filament\\Pages\\Auth\\PasswordReset\\ResetPassword',
    'app.filament.widgets.balance-history-stats' => 'App\\Filament\\Widgets\\BalanceHistoryStats',
  ),
  'clusters' => 
  array (
  ),
  'clusteredComponents' => 
  array (
  ),
  'clusterDirectories' => 
  array (
  ),
  'clusterNamespaces' => 
  array (
  ),
  'pages' => 
  array (
    'C:\\xampp\\htdocs\\airlinks\\app\\Filament\\Pages\\AgentMonthlyOrders.php' => 'App\\Filament\\Pages\\AgentMonthlyOrders',
    'C:\\xampp\\htdocs\\airlinks\\app\\Filament\\Pages\\DailyBalance.php' => 'App\\Filament\\Pages\\DailyBalance',
    'C:\\xampp\\htdocs\\airlinks\\app\\Filament\\Pages\\Dashboard.php' => 'App\\Filament\\Pages\\Dashboard',
    'C:\\xampp\\htdocs\\airlinks\\app\\Filament\\Pages\\DataProviderSettings.php' => 'App\\Filament\\Pages\\DataProviderSettings',
    'C:\\xampp\\htdocs\\airlinks\\app\\Filament\\Pages\\PaymentSettings.php' => 'App\\Filament\\Pages\\PaymentSettings',
    'C:\\xampp\\htdocs\\airlinks\\app\\Filament\\Pages\\ProfitReport.php' => 'App\\Filament\\Pages\\ProfitReport',
    'C:\\xampp\\htdocs\\airlinks\\app\\Filament\\Pages\\SalesAnalytics.php' => 'App\\Filament\\Pages\\SalesAnalytics',
    'C:\\xampp\\htdocs\\airlinks\\app\\Filament\\Pages\\SmtpSettings.php' => 'App\\Filament\\Pages\\SmtpSettings',
    0 => 'App\\Filament\\Pages\\Dashboard',
  ),
  'pageDirectories' => 
  array (
    0 => 'C:\\xampp\\htdocs\\airlinks\\app\\Filament/Pages',
  ),
  'pageNamespaces' => 
  array (
    0 => 'App\\Filament\\Pages',
  ),
  'resources' => 
  array (
    'C:\\xampp\\htdocs\\airlinks\\app\\Filament\\Resources\\AgentPackageResource.php' => 'App\\Filament\\Resources\\AgentPackageResource',
    'C:\\xampp\\htdocs\\airlinks\\app\\Filament\\Resources\\AgentStoreSettingResource.php' => 'App\\Filament\\Resources\\AgentStoreSettingResource',
    'C:\\xampp\\htdocs\\airlinks\\app\\Filament\\Resources\\ApiConfigResource.php' => 'App\\Filament\\Resources\\ApiConfigResource',
    'C:\\xampp\\htdocs\\airlinks\\app\\Filament\\Resources\\ApiLogResource.php' => 'App\\Filament\\Resources\\ApiLogResource',
    'C:\\xampp\\htdocs\\airlinks\\app\\Filament\\Resources\\BalanceHistoryResource.php' => 'App\\Filament\\Resources\\BalanceHistoryResource',
    'C:\\xampp\\htdocs\\airlinks\\app\\Filament\\Resources\\CustomerPackageResource.php' => 'App\\Filament\\Resources\\CustomerPackageResource',
    'C:\\xampp\\htdocs\\airlinks\\app\\Filament\\Resources\\DealerPackageResource.php' => 'App\\Filament\\Resources\\DealerPackageResource',
    'C:\\xampp\\htdocs\\airlinks\\app\\Filament\\Resources\\DealerResource.php' => 'App\\Filament\\Resources\\DealerResource',
    'C:\\xampp\\htdocs\\airlinks\\app\\Filament\\Resources\\MtnMashupResource.php' => 'App\\Filament\\Resources\\MtnMashupResource',
    'C:\\xampp\\htdocs\\airlinks\\app\\Filament\\Resources\\NotificationResource.php' => 'App\\Filament\\Resources\\NotificationResource',
    'C:\\xampp\\htdocs\\airlinks\\app\\Filament\\Resources\\OrderResource.php' => 'App\\Filament\\Resources\\OrderResource',
    'C:\\xampp\\htdocs\\airlinks\\app\\Filament\\Resources\\OrderStatusHistoryResource.php' => 'App\\Filament\\Resources\\OrderStatusHistoryResource',
    'C:\\xampp\\htdocs\\airlinks\\app\\Filament\\Resources\\PaymentConfigResource.php' => 'App\\Filament\\Resources\\PaymentConfigResource',
    'C:\\xampp\\htdocs\\airlinks\\app\\Filament\\Resources\\SupportTicketResource.php' => 'App\\Filament\\Resources\\SupportTicketResource',
    'C:\\xampp\\htdocs\\airlinks\\app\\Filament\\Resources\\UserResource.php' => 'App\\Filament\\Resources\\UserResource',
    'C:\\xampp\\htdocs\\airlinks\\app\\Filament\\Resources\\WalletTopupResource.php' => 'App\\Filament\\Resources\\WalletTopupResource',
  ),
  'resourceDirectories' => 
  array (
    0 => 'C:\\xampp\\htdocs\\airlinks\\app\\Filament/Resources',
  ),
  'resourceNamespaces' => 
  array (
    0 => 'App\\Filament\\Resources',
  ),
  'widgets' => 
  array (
    0 => 'App\\Filament\\Widgets\\WalletTopupStats',
  ),
  'widgetDirectories' => 
  array (
  ),
  'widgetNamespaces' => 
  array (
  ),
);