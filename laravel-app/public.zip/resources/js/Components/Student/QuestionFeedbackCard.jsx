import { useState } from 'react';

function typeLabel(qType) {
    switch (qType) {
        case 'mcq':
            return 'Multiple choice';
        case 'fill_in':
            return 'Fill in';
        case 'theory':
            return 'Theory';
        case 'file':
            return 'File upload';
        default:
            return qType || 'Question';
    }
}

function statusBadgeClass(status) {
    const s = (status || '').toLowerCase();
    if (s === 'correct') {
        return 'border-emerald-600/50 bg-emerald-500/15 text-emerald-800 dark:text-emerald-200';
    }
    if (s === 'partial') {
        return 'border-amber-600/50 bg-amber-500/15 text-amber-900 dark:text-amber-100';
    }
    if (s === 'incorrect' || s === 'unanswered') {
        return 'border-rose-600/50 bg-rose-500/15 text-rose-900 dark:text-rose-100';
    }
    return 'border-theme-line bg-theme-highlight text-theme-muted';
}

function ConceptTags({ title, items, tone }) {
    if (!items || items.length === 0) {
        return null;
    }
    const wrap =
        tone === 'weak'
            ? 'border-rose-500/30 bg-rose-950/20'
            : 'border-emerald-500/30 bg-emerald-950/20';
    return (
        <div>
            <p className="mb-1.5 text-xs font-semibold uppercase tracking-wide text-theme-dim">
                {title}
            </p>
            <div className={`flex flex-wrap gap-1.5 rounded-lg border px-2 py-2 ${wrap}`}>
                {items.map((c) => (
                    <span
                        key={c}
                        className="rounded-md bg-theme-glass px-2 py-0.5 text-xs text-theme-strong"
                    >
                        {c}
                    </span>
                ))}
            </div>
        </div>
    );
}

export default function QuestionFeedbackCard({ item, flags }) {
    const [open, setOpen] = useState(true);
    if (!item) {
        return null;
    }

    const showExpected = flags?.show_expected_answers;
    const showAi = flags?.show_ai_feedback;

    const confPct =
        item.ai_confidence != null
            ? Math.round(Number(item.ai_confidence) * 100)
            : null;

    const status = item.display_status || '—';

    return (
        <div className="overflow-hidden rounded-xl border border-theme-line bg-theme-glass shadow-sm">
            <button
                type="button"
                onClick={() => setOpen(!open)}
                className="flex w-full flex-col gap-2 px-4 py-3 text-left sm:flex-row sm:items-center sm:justify-between"
            >
                <div className="min-w-0 flex-1">
                    <p className="text-xs font-semibold uppercase tracking-wide text-theme-dim">
                        {typeLabel(item.q_type)}
                    </p>
                    <p className="mt-1 line-clamp-2 text-sm font-medium text-theme-strong">
                        {item.question_text}
                    </p>
                </div>
                <div className="flex flex-shrink-0 flex-wrap items-center gap-2">
                    <span
                        className={`rounded-md border px-2 py-1 text-xs font-semibold capitalize ${statusBadgeClass(status)}`}
                    >
                        {status}
                    </span>
                    <span className="font-mono text-sm text-theme-strong">
                        {Number(item.marks_counted ?? 0).toFixed(2)} /{' '}
                        {Number(item.max_marks ?? 0).toFixed(2)}
                    </span>
                    <span className="text-xs text-theme-dim">{open ? '▼' : '▶'}</span>
                </div>
            </button>

            {open && (
                <div className="space-y-4 border-t border-theme-line px-4 py-4 text-sm">
                    {item.q_type === 'mcq' ? (
                        <dl className="grid gap-3 sm:grid-cols-2">
                            <div>
                                <dt className="text-xs text-theme-dim">Your choice</dt>
                                <dd className="mt-0.5 text-theme-strong">
                                    {item.selected_option
                                        ? `${item.selected_option}${
                                              item.selected_option_text
                                                  ? ` — ${item.selected_option_text}`
                                                  : ''
                                          }`
                                        : '—'}
                                </dd>
                            </div>
                            {showExpected ? (
                                <div>
                                    <dt className="text-xs text-theme-dim">Correct option</dt>
                                    <dd className="mt-0.5 text-theme-strong">
                                        {item.correct_option
                                            ? `${item.correct_option}${
                                                  item.correct_option_text
                                                      ? ` — ${item.correct_option_text}`
                                                      : ''
                                              }`
                                            : '—'}
                                    </dd>
                                </div>
                            ) : null}
                        </dl>
                    ) : null}

                    {item.q_type === 'fill_in' ? (
                        <dl className="grid gap-3">
                            <div>
                                <dt className="text-xs text-theme-dim">Your answer</dt>
                                <dd className="mt-0.5 whitespace-pre-wrap text-theme-strong">
                                    {item.student_answer ?? '—'}
                                </dd>
                            </div>
                            <div className="grid gap-2 sm:grid-cols-2">
                                <div>
                                    <dt className="text-xs text-theme-dim">
                                        Normalized (for matching)
                                    </dt>
                                    <dd className="mt-0.5 font-mono text-xs text-theme-muted">
                                        {item.normalized_student_fill_in || '—'}
                                    </dd>
                                </div>
                                {showExpected ? (
                                    <div>
                                        <dt className="text-xs text-theme-dim">
                                            Accepted answer
                                        </dt>
                                        <dd className="mt-0.5 text-theme-strong">
                                            {item.accepted_fill_in ?? '—'}
                                        </dd>
                                    </div>
                                ) : null}
                            </div>
                            <div>
                                <dt className="text-xs text-theme-dim">Match result</dt>
                                <dd className="mt-0.5 text-theme-strong">
                                    {item.fill_in_match === true
                                        ? 'Matched (normalized)'
                                        : item.fill_in_match === false
                                          ? 'No match'
                                          : '—'}
                                </dd>
                            </div>
                        </dl>
                    ) : null}

                    {(item.q_type === 'theory' || item.q_type === 'file') && (
                        <dl className="grid gap-3">
                            {item.q_type === 'theory' ? (
                                <div>
                                    <dt className="text-xs text-theme-dim">Your answer</dt>
                                    <dd className="mt-0.5 max-h-48 overflow-y-auto whitespace-pre-wrap text-theme-strong">
                                        {item.student_answer ?? '—'}
                                    </dd>
                                </div>
                            ) : null}
                            {item.q_type === 'file' ? (
                                <div>
                                    <dt className="text-xs text-theme-dim">Submission</dt>
                                    <dd className="mt-0.5 text-theme-strong">
                                        {item.file_upload_name
                                            ? `Uploaded file: ${item.file_upload_name}`
                                            : 'No file on record'}
                                    </dd>
                                </div>
                            ) : null}
                            {showExpected && item.expected_answer ? (
                                <div>
                                    <dt className="text-xs text-theme-dim">
                                        Reference / expected
                                    </dt>
                                    <dd className="mt-0.5 whitespace-pre-wrap text-theme-strong">
                                        {item.expected_answer}
                                    </dd>
                                </div>
                            ) : null}
                        </dl>
                    )}

                    {item.marks_recorded != null &&
                    Math.abs(
                        Number(item.marks_recorded) - Number(item.marks_counted),
                    ) > 0.01 ? (
                        <p className="rounded-md border border-sky-500/30 bg-sky-950/25 px-3 py-2 text-xs text-sky-100">
                            Recorded mark on file:{' '}
                            <span className="font-mono font-semibold">
                                {Number(item.marks_recorded).toFixed(2)}
                            </span>{' '}
                            — your graded total uses{' '}
                            <span className="font-mono font-semibold">
                                {Number(item.marks_counted).toFixed(2)}
                            </span>{' '}
                            toward the exam score (e.g. after normalization or
                            lecturer adjustment).
                        </p>
                    ) : null}

                    {showAi ? (
                        <div className="space-y-3 rounded-lg border border-violet-500/25 bg-violet-950/20 p-3">
                            <div className="flex flex-wrap items-center gap-2">
                                {item.evaluation_status ? (
                                    <span className="rounded border border-violet-400/40 px-2 py-0.5 text-xs font-semibold uppercase tracking-wide text-violet-100">
                                        AI: {item.evaluation_status}
                                    </span>
                                ) : null}
                                {confPct != null ? (
                                    <span className="rounded border border-sky-500/40 bg-sky-950/40 px-2 py-0.5 text-xs text-sky-100">
                                        Confidence {confPct}%
                                    </span>
                                ) : null}
                                {item.q_type === 'theory' &&
                                item.ai_concept_coverage != null ? (
                                    <span className="rounded border border-violet-500/40 bg-violet-950/40 px-2 py-0.5 text-xs text-violet-100">
                                        Concept coverage{' '}
                                        {Math.round(
                                            Number(item.ai_concept_coverage) *
                                                100,
                                        )}
                                        %
                                    </span>
                                ) : null}
                            </div>
                            {item.evaluation_reason ? (
                                <div>
                                    <p className="text-xs font-semibold text-theme-dim">
                                        Evaluation
                                    </p>
                                    <p className="mt-1 text-sm text-theme-muted">
                                        {item.evaluation_reason}
                                    </p>
                                </div>
                            ) : null}
                            {item.ai_evaluation ? (
                                <div>
                                    <p className="text-xs font-semibold text-theme-dim">
                                        Additional AI notes
                                    </p>
                                    <p className="mt-1 whitespace-pre-wrap text-sm text-theme-muted">
                                        {item.ai_evaluation}
                                    </p>
                                </div>
                            ) : null}
                            <ConceptTags
                                title="Rubric concepts (AI)"
                                items={item.rubric_concepts}
                                tone="strong"
                            />
                            <ConceptTags
                                title="Strengths (detected concepts)"
                                items={item.detected_concepts}
                                tone="strong"
                            />
                            <ConceptTags
                                title="Gaps (missing concepts)"
                                items={item.missing_concepts}
                                tone="weak"
                            />
                            {item.revision_suggestion ? (
                                <div>
                                    <p className="text-xs font-semibold text-amber-200/90">
                                        Revision tip
                                    </p>
                                    <p className="mt-1 text-sm text-amber-50/95">
                                        {item.revision_suggestion}
                                    </p>
                                </div>
                            ) : null}
                        </div>
                    ) : (
                        <p className="text-xs text-theme-dim">
                            Detailed AI feedback is hidden for this exam. You can
                            still see your marks above.
                        </p>
                    )}
                </div>
            )}
        </div>
    );
}
