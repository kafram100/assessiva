export default function RevisionSuggestionCard({
    revisionPlanSummary,
    aggregatedMissing,
    aiEnabled,
    revisionEnabled,
}) {
    if (!aiEnabled && !revisionEnabled) {
        return null;
    }

    if (aiEnabled && !revisionEnabled) {
        if (!aggregatedMissing || aggregatedMissing.length === 0) {
            return null;
        }
        return (
            <div className="rounded-xl border border-indigo-500/30 bg-indigo-950/25 px-4 py-4 shadow-sm">
                <h2 className="text-sm font-semibold uppercase tracking-widest text-indigo-100/90">
                    Concepts to revisit
                </h2>
                <ul className="mt-3 list-inside list-disc space-y-1 text-sm text-theme-muted">
                    {aggregatedMissing.slice(0, 20).map((c) => (
                        <li key={c}>{c}</li>
                    ))}
                </ul>
            </div>
        );
    }

    const hasPlan =
        revisionPlanSummary &&
        (revisionPlanSummary.summary ||
            (revisionPlanSummary.weak_topics &&
                revisionPlanSummary.weak_topics.length > 0));

    return (
        <div className="rounded-xl border border-indigo-500/30 bg-indigo-950/25 px-4 py-4 shadow-sm">
            <h2 className="text-sm font-semibold uppercase tracking-widest text-indigo-100/90">
                Learning and revision focus
            </h2>

            {aiEnabled && aggregatedMissing && aggregatedMissing.length > 0 ? (
                <div className="mt-3">
                    <p className="text-xs font-semibold text-theme-dim">
                        Concepts to revisit (from your answers)
                    </p>
                    <ul className="mt-2 list-inside list-disc space-y-1 text-sm text-theme-muted">
                        {aggregatedMissing.slice(0, 20).map((c) => (
                            <li key={c}>{c}</li>
                        ))}
                    </ul>
                </div>
            ) : aiEnabled ? (
                <p className="mt-3 text-sm text-theme-muted">
                    No cross-question concept gaps were recorded. Keep practicing
                    varied questions on the same course outcomes.
                </p>
            ) : null}

            {hasPlan ? (
                <div className="mt-4 border-t border-indigo-500/20 pt-4">
                    {revisionPlanSummary.summary ? (
                        <p className="text-sm leading-relaxed text-theme-muted">
                            {revisionPlanSummary.summary}
                        </p>
                    ) : null}
                    {revisionPlanSummary.weak_topics &&
                    revisionPlanSummary.weak_topics.length > 0 ? (
                        <div className="mt-3">
                            <p className="text-xs font-semibold text-theme-dim">
                                Weak topics (AI plan)
                            </p>
                            <div className="mt-2 flex flex-wrap gap-1.5">
                                {revisionPlanSummary.weak_topics
                                    .slice(0, 12)
                                    .map((t) => (
                                        <span
                                            key={t}
                                            className="rounded-md border border-indigo-400/30 bg-indigo-950/40 px-2 py-0.5 text-xs text-indigo-100"
                                        >
                                            {t}
                                        </span>
                                    ))}
                            </div>
                        </div>
                    ) : null}
                    {revisionPlanSummary.recommended_actions &&
                    revisionPlanSummary.recommended_actions.length > 0 ? (
                        <div className="mt-3">
                            <p className="text-xs font-semibold text-theme-dim">
                                Recommended actions
                            </p>
                            <ul className="mt-2 list-inside list-disc space-y-1 text-sm text-theme-muted">
                                {revisionPlanSummary.recommended_actions
                                    .slice(0, 8)
                                    .map((a, i) => (
                                        <li key={i}>{a}</li>
                                    ))}
                            </ul>
                        </div>
                    ) : null}
                </div>
            ) : (
                <p className="mt-4 text-xs text-theme-dim">
                    Open your full AI revision plan for flashcards, study steps,
                    and practice prompts tailored to this attempt.
                </p>
            )}
        </div>
    );
}
